# OpenShift Single Node (SNO) na OCI — Terraform + Agent Installer

Este pacote cria **rede + NSG + IP público + instância** na Oracle Cloud (OCI) para instalar um **OpenShift SNO** de forma automatizada via **Agent-based Installer**. 
Para simplicidade, o Terraform **não gera a imagem** do agente; você informa o **OCID da Custom Image** (criada a partir do Agent ISO) e o Terraform cria a VM já apontando para ela.

> **Importante:** OpenShift SNO usa **RHCOS**; não é possível usar Ubuntu no nó. Para OKD, utiliza **FCOS**. Você *pode* usar Ubuntu apenas como bastion.

---

## Visão geral

1. **Gerar artefatos do Agent Installer** no seu bastion (Linux):
   - `openshift-install agent create image` (OCP) **ou** `openshift-install --dir ... create single-node-ignition-config`/OKD equivalente.
   - Você terá um **Agent ISO**.
2. **Criar uma Custom Image UEFI** na OCI a partir desse ISO (via Console/CLI).
3. **Executar o Terraform** para rede e compute usando `image_ocid` da imagem criada.
4. Acompanhar a instalação: `openshift-install agent wait-for install-complete`.

---

## Pré-requisitos

- Terraform >= 1.5
- OCI CLI configurado (`oci setup config`)
- Credenciais/OCIDs: Tenancy, User, Compartment, Region, Fingerprint, Chave privada.
- `openshift-install` compatível com a versão desejada (OCP ou OKD).

---

## Estrutura

```text
terraform/ (infra OCI)
  provider.tf
  variables.tf
  main.tf
  outputs.tf
install/ (modelos para seu agente)
  install-config.yaml (SNO)
  agent-config.yaml   (SNO)
```

---

## Como criar a **Custom Image** do Agent ISO (resumo)

1. Gere o ISO do agente no seu bastion:
   ```bash
   openshift-install agent create image          --dir ./work          --log-level debug
   # Resultado: ./work/agent.iso
   ```

2. Envie `agent.iso` para um Bucket no **Object Storage** (mesmo tenancy/region).
3. No Console OCI: **Compute > Custom Images > Import image**  
   - **Operating system**: Linux (UEFI)  
   - **Image type / Source**: Object Storage URL (forneça o pre-auth link)  
   - Finalize e aguarde o **OCID** da imagem.

   > Observação: alguns fluxos pedem uma imagem no formato **OCI/RAW**. Se sua tenancy não aceitar ISO diretamente, converta o ISO para um **disco bootável** (RAW/QCOW2 -> TAR) seguindo a doc. Nesse caso, use o **boot artifacts** (HTTP boot) como alternativa. Ajuste conforme sua versão/tenancy.

---

## Deploy com Terraform

1. Entre em `terraform/` e crie um arquivo `terraform.tfvars`:
   ```hcl
   tenancy_ocid     = "ocid1.tenancy.oc1..aaaa..."
   user_ocid        = "ocid1.user.oc1..aaaa..."
   fingerprint      = "aa:bb:cc:dd:..."
   private_key_path = "~/.oci/oci_api_key.pem"
   region           = "sa-saopaulo-1"
   compartment_ocid = "ocid1.compartment.oc1..aaaa..."
   ad               = "KIdk:SA-SAOPAULO-1-AD-1"

   # Shape flex recomendado p/ SNO lab
   shape            = "VM.Standard.E5.Flex"
   ocpus            = 4    # 4 OCPU = 8 vCPU
   memory_gbs       = 32
   boot_volume_gbs  = 200

   image_ocid       = "ocid1.image.oc1.sa-saopaulo-1.aaaa..."  # Custom Image do Agent
   ssh_authorized_keys = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAA... seu@pc"
   ```

2. Inicialize e aplique:
   ```bash
   terraform init
   terraform apply -auto-approve
   ```

3. Saída principal: `sno_public_ip`. Conecte via SSH:
   ```bash
   ssh core@$(terraform output -raw sno_public_ip)
   ```

---

## DNS e Acesso (opcional)

Para produção, crie DNS para:
- `api.<cluster>.<baseDomain>` → IP público/Load Balancer
- `*.apps.<cluster>.<baseDomain>` → Ingress
Em SNO, muita gente começa com **NodePort** e depois adiciona **LB**.

---

## Ajustes SNO (YAMLs)

Você encontra modelos em `install/`. Edite **clusterName**, **baseDomain**, **pullSecret**, **sshKey** e **rendezvousIP** conforme seu ambiente.

---

## Limpeza

```bash
terraform destroy -auto-approve
```

---

## Troubleshooting rápido

- **Falhou o boot do agente**: valide se a imagem foi importada como **UEFI** e se o shape suporta UEFI boot.
- **Sem IP público**: confira `assign_public_ip = true` e se há roteamento/IGW.
- **Instalação não finaliza**: confira `rendezvousIP`, portas liberadas (6443, 22624), DNS alcançável do nó e `pullSecret` válido (OCP).

